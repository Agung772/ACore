using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;
#if ODIN_INSPECTOR
using Sirenix.OdinInspector.Editor;
#endif

namespace CutsceneGraph.Editor
{
    public class CutsceneNodeView : Node
    {
        public string guid;
        public NodeData nodeData;
        public Port inputPort;
        public Port outputPort;
        public readonly Dictionary<string, Port> extraOutputPorts = new Dictionary<string, Port>();

        private VisualElement fieldsContainer;
        private CutsceneData ownerData;
        private int lastChoiceCount = -1;
        private string lastChoiceKeys = "";

        private SerializedObject serializedGraph;
        private SerializedProperty eventDataProperty;
        private int cachedNodeIndex = -1;
#if ODIN_INSPECTOR
        private PropertyTree odinTree;
        private object odinTreeTarget;
#endif

        public bool IsStartNode => nodeData?.eventData is StartEvent; 
        public CutsceneNodeView(NodeData nodeData, CutsceneData cutsceneData = null)
        {
            this.nodeData = nodeData;
            ownerData = cutsceneData;
            guid = nodeData.guid;
            viewDataKey = nodeData.guid;

            style.width = 280;
            style.minWidth = 260;
            style.transitionProperty = new List<StylePropertyName>
            {
                new StylePropertyName("scale"),
                new StylePropertyName("opacity"),
                new StylePropertyName("border-top-color"),
                new StylePropertyName("border-bottom-color"),
                new StylePropertyName("border-left-color"),
                new StylePropertyName("border-right-color"),
                new StylePropertyName("background-color")
            };
            style.transitionDuration = new List<TimeValue>
            {
                new TimeValue(0.18f), new TimeValue(0.18f),
                new TimeValue(0.2f), new TimeValue(0.2f),
                new TimeValue(0.2f), new TimeValue(0.2f), new TimeValue(0.2f)
            };
            style.transitionTimingFunction = new List<EasingFunction>
            {
                new EasingFunction(EasingMode.EaseOutCubic)
            };

            bool _isStart = nodeData.eventData is StartEvent;

            if (!_isStart)
            {
                inputPort = InstantiatePort(Orientation.Horizontal, Direction.Input, Port.Capacity.Multi, typeof(bool));
                inputPort.portName = "";
                inputContainer.Add(inputPort);
            }

            RebuildOutputPorts(false);

            UpdateTitle();
            ApplyNodeChrome();

            if (!_isStart)
            {
                var _divider = new VisualElement();
                _divider.style.height = 1;
                _divider.style.marginLeft = 8;
                _divider.style.marginRight = 8;
                _divider.style.marginTop = 2;
                _divider.style.marginBottom = 2;
                _divider.style.backgroundColor = new Color(1f, 1f, 1f, 0.09f);
                mainContainer.Add(_divider);

                fieldsContainer = new VisualElement();
                fieldsContainer.style.marginTop = 2;
                fieldsContainer.style.marginLeft = 6;
                fieldsContainer.style.marginRight = 6;
                fieldsContainer.style.marginBottom = 8;
                mainContainer.Add(fieldsContainer);

                var _imgui = new IMGUIContainer(DrawEventInspector);
                _imgui.style.marginTop = 2;
                _imgui.style.marginBottom = 4;
                fieldsContainer.Add(_imgui);
                _imgui.schedule.Execute(() => _imgui.MarkDirtyRepaint()).Every(80);
            }
            else
            {
                var _info = new Label("Entry Point");
                _info.style.unityFontStyleAndWeight = FontStyle.Italic;
                _info.style.marginTop = 10;
                _info.style.marginBottom = 12;
                _info.style.unityTextAlign = TextAnchor.MiddleCenter;
                _info.style.color = new Color(0.55f, 0.95f, 0.72f, 1f);
                _info.style.fontSize = 11;
                _info.style.letterSpacing = 0.6f;
                mainContainer.Add(_info);
            }

            RefreshExpandedState();
            RefreshPorts();

            this.AddManipulator(new ContextualMenuManipulator(BuildNodeContextMenu));
            RegisterCallback<AttachToPanelEvent>(_ =>
            {
                SetupEdgeConnectors();
                style.opacity = 0f;
                style.scale = new Scale(new Vector3(0.92f, 0.92f, 1f));
                schedule.Execute(() =>
                {
                    style.opacity = 1f;
                    style.scale = new Scale(Vector3.one);
                }).ExecuteLater(20);
            });
            RegisterCallback<MouseDownEvent>(OnNodeMouseDown);
            RegisterCallback<MouseEnterEvent>(_ =>
            {
                if (!selected)
                    style.scale = new Scale(new Vector3(1.025f, 1.025f, 1f));
            });
            RegisterCallback<MouseLeaveEvent>(_ =>
            {
                if (!selected)
                    style.scale = new Scale(Vector3.one);
            });
        }

        private void OnNodeMouseDown(MouseDownEvent evt)
        {
            if (evt.button == 0 && ownerData != null && !IsStartNode)
                Undo.RegisterCompleteObjectUndo(ownerData, "Move Cutscene Node");

            if (evt.clickCount < 2) return;
            if (nodeData?.eventData is not FlowEvent _flow) return;
            if (!_flow.CanOpenSubGraph) return;

            evt.StopPropagation();
            var _win = EditorWindow.GetWindow<CutsceneGraphWindow>();
            if (_win != null)
                _win.OpenFlowTab(_flow, ownerData);
        }

        private void SetupEdgeConnectors()
        {
            var _gv = GetFirstAncestorOfType<CutsceneGraphView>();
            if (_gv == null) return;
            var _listener = new CutsceneEdgeConnectorListener(_gv);
            AttachConnector(inputPort, _listener);
            AttachConnector(outputPort, _listener);
            foreach (var _port in extraOutputPorts.Values)
                AttachConnector(_port, _listener);
        }

        private static void AttachConnector(Port port, IEdgeConnectorListener listener)
        {
            if (port == null) return;
            port.AddManipulator(new EdgeConnector<Edge>(listener));
        }

        public Port GetOutputPort(string portId)
        {
            if (!string.IsNullOrEmpty(portId) && extraOutputPorts.TryGetValue(portId, out var _p))
                return _p;
            return outputPort;
        }

        public void RebuildOutputPorts(bool restoreEdges = true)
        {
            var _graphView = GetFirstAncestorOfType<CutsceneGraphView>();
            var _saved = new List<(string portId, string targetGuid)>();

            if (restoreEdges && _graphView != null)
            {
                foreach (var _edge in _graphView.edges.ToList())
                {
                    if (_edge.output?.node != this) continue;
                    var _target = _edge.input?.node as CutsceneNodeView;
                    if (_target == null) continue;
                    string _portId = _edge.output.userData as string ?? "";
                    _saved.Add((_portId, _target.guid));
                    _graphView.RemoveElement(_edge);
                }
            }

            foreach (var _port in extraOutputPorts.Values.ToList())
            {
                _port?.DisconnectAll();
                if (_port?.parent != null) _port.parent.Remove(_port);
            }
            extraOutputPorts.Clear();

            if (outputPort != null)
            {
                outputPort.DisconnectAll();
                if (outputPort.parent != null) outputPort.parent.Remove(outputPort);
                outputPort = null;
            }

            var _dynamicPorts = nodeData?.eventData?.OutputPorts;
            if (_dynamicPorts != null && _dynamicPorts.Count > 0)
            {
                var _usedKeys = new HashSet<string>();
                for (int _i = 0; _i < _dynamicPorts.Count; _i++)
                {
                    var _info = _dynamicPorts[_i];
                    if (_info == null) continue;
                    string _portId = string.IsNullOrWhiteSpace(_info.PortID) ? $"out_{_i}" : _info.PortID.Trim();
                    if (_usedKeys.Contains(_portId))
                        _portId = $"{_portId}_{_i}";
                    _usedKeys.Add(_portId);

                    var _port = MakeOutputPort(_portId, _portId, Port.Capacity.Multi);
                    outputContainer.Add(_port);
                    extraOutputPorts[_portId] = _port;
                }
            }
            else
            {
                outputPort = MakeOutputPort("", "", Port.Capacity.Multi);
                outputContainer.Add(outputPort);
            }

            ApplyPortColors();
            RefreshPorts();
            SetupEdgeConnectors();

            if (restoreEdges && _graphView != null)
            {
                foreach (var (_portId, _targetGuid) in _saved)
                {
                    var _target = _graphView.GetNodeViewPublic(_targetGuid);
                    if (_target?.inputPort == null) continue;
                    var _src = GetOutputPort(_portId);
                    if (_src == null) continue;
                    if (_src.connected) continue;
                    var _edge = _src.ConnectTo(_target.inputPort);
                    _graphView.AddElement(_edge);
                }

                if (_graphView.CurrentData != null)
                    SyncLinksFromView(_graphView);
            }

            CacheOutputPortSignature();
        }

        private Port MakeOutputPort(string portId, string name, Port.Capacity capacity)
        {
            var _port = InstantiatePort(Orientation.Horizontal, Direction.Output, capacity, typeof(bool));
            _port.portName = name ?? "";
            _port.userData = portId ?? "";
            return _port;
        }

        private void CacheOutputPortSignature()
        {
            lastChoiceCount = GetOutputPortCount();
            lastChoiceKeys = GetOutputPortSignature();
        }

        private bool OutputPortSignatureChanged()
        {
            return GetOutputPortCount() != lastChoiceCount || GetOutputPortSignature() != lastChoiceKeys;
        }

        private void SyncLinksFromView(CutsceneGraphView graphView)
        {
            if (graphView?.CurrentData == null) return;
            var _graph = graphView.CurrentData;
            _graph.data.links.RemoveAll(l => l.baseNodeGuid == guid);
            foreach (var _edge in graphView.edges)
            {
                if (_edge.output?.node != this) continue;
                var _target = _edge.input?.node as CutsceneNodeView;
                if (_target == null) continue;
                _graph.data.links.Add(new NodeLink
                {
                    baseNodeGuid = guid,
                    targetNodeGuid = _target.guid,
                    outputPortId = _edge.output.userData as string ?? ""
                });
            }
            EditorUtility.SetDirty(_graph);
        }

        private void ApplyPortColors()
        {
            Color _accent = nodeData?.eventData != null
                ? nodeData.eventData.NodeColor
                : new Color(0.42f, 0.44f, 0.52f, 0.95f);
            if (inputPort != null) inputPort.portColor = _accent;
            if (outputPort != null) outputPort.portColor = _accent;
            foreach (var _port in extraOutputPorts.Values)
                if (_port != null) _port.portColor = _accent;
        }

        private void ApplyNodeChrome()
        {
            Color _accent = nodeData?.eventData != null
                ? nodeData.eventData.NodeColor
                : new Color(0.42f, 0.44f, 0.52f, 0.95f);

            bool _isFlow = nodeData?.eventData is FlowEvent;
            bool _isStart = nodeData?.eventData is StartEvent;

            Color _softBorder = new Color(_accent.r, _accent.g, _accent.b, selected ? 0.85f : 0.55f);
            style.borderTopColor = _softBorder;
            style.borderBottomColor = _softBorder;
            style.borderRightColor = _softBorder;
            style.borderLeftColor = _accent;
            style.backgroundColor = selected
                ? new Color(0.16f, 0.17f, 0.20f, 0.98f)
                : new Color(0.13f, 0.135f, 0.155f, 0.97f);

            style.borderTopLeftRadius = 12;
            style.borderTopRightRadius = 12;
            style.borderBottomLeftRadius = 12;
            style.borderBottomRightRadius = 12;
            style.borderTopWidth = selected ? 2f : 1.5f;
            style.borderBottomWidth = selected ? 2f : 1.5f;
            style.borderLeftWidth = _isStart ? 5f : 4f;
            style.borderRightWidth = selected ? 2f : 1.5f;

            Color _titleBg = new Color(
                Mathf.Lerp(0.11f, _accent.r, selected ? 0.48f : 0.38f),
                Mathf.Lerp(0.11f, _accent.g, selected ? 0.48f : 0.38f),
                Mathf.Lerp(0.13f, _accent.b, selected ? 0.48f : 0.38f),
                1f);

            var _titleContainer = this.Q("title");
            if (_titleContainer != null)
            {
                _titleContainer.style.backgroundColor = _titleBg;
                _titleContainer.style.borderTopLeftRadius = 11;
                _titleContainer.style.borderTopRightRadius = 11;
                _titleContainer.style.paddingLeft = 8;
                _titleContainer.style.paddingRight = 8;
                _titleContainer.style.minHeight = 28;
            }

            var _titleLabel = this.Q<Label>("title-label");
            if (_titleLabel != null)
            {
                _titleLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
                _titleLabel.style.fontSize = 12;
                _titleLabel.style.color = new Color(0.94f, 0.95f, 0.98f, 1f);
                _titleLabel.style.letterSpacing = 0.3f;
            }

            var _collapseBtn = this.Q("collapse-button");
            if (_collapseBtn != null)
                _collapseBtn.style.display = DisplayStyle.None;

            ApplyFlowLayeredLook(_isFlow, _accent);
            ApplyPortColors();
        }

        private void ApplyFlowLayeredLook(bool isFlow, Color accent)
        {
            var _oldLayers = this.Query<VisualElement>(className: "flow-layer").ToList();
            foreach (var _el in _oldLayers)
                _el.RemoveFromHierarchy();

            var _oldBadge = this.Q<Label>(className: "flow-badge");
            _oldBadge?.RemoveFromHierarchy();

            if (!isFlow) return;

            Color _border = new Color(accent.r, accent.g, accent.b, 0.22f);
            Color _bg = new Color(0.14f, 0.145f, 0.165f, 0.9f);

            var _layer2 = new VisualElement();
            _layer2.AddToClassList("flow-layer");
            _layer2.pickingMode = PickingMode.Ignore;
            _layer2.style.position = Position.Absolute;
            _layer2.style.left = -10;
            _layer2.style.top = 5;
            _layer2.style.right = 5;
            _layer2.style.bottom = -10;
            _layer2.style.backgroundColor = _bg;
            _layer2.style.borderTopLeftRadius = 10;
            _layer2.style.borderTopRightRadius = 10;
            _layer2.style.borderBottomLeftRadius = 10;
            _layer2.style.borderBottomRightRadius = 10;
            _layer2.style.borderLeftWidth = 1.5f;
            _layer2.style.borderTopWidth = 1.5f;
            _layer2.style.borderRightWidth = 1.5f;
            _layer2.style.borderBottomWidth = 1.5f;
            _layer2.style.borderLeftColor = _border;
            _layer2.style.borderTopColor = _border;
            _layer2.style.borderRightColor = _border;
            _layer2.style.borderBottomColor = _border;
            Insert(0, _layer2);

            var _layer1 = new VisualElement();
            _layer1.AddToClassList("flow-layer");
            _layer1.pickingMode = PickingMode.Ignore;
            _layer1.style.position = Position.Absolute;
            _layer1.style.left = -5;
            _layer1.style.top = 0;
            _layer1.style.right = 5;
            _layer1.style.bottom = -5;
            _layer1.style.backgroundColor = _bg;
            _layer1.style.borderTopLeftRadius = 10;
            _layer1.style.borderTopRightRadius = 10;
            _layer1.style.borderBottomLeftRadius = 10;
            _layer1.style.borderBottomRightRadius = 10;
            _layer1.style.borderLeftWidth = 1.5f;
            _layer1.style.borderTopWidth = 1.5f;
            _layer1.style.borderRightWidth = 1.5f;
            _layer1.style.borderBottomWidth = 1.5f;
            _layer1.style.borderLeftColor = _border;
            _layer1.style.borderTopColor = _border;
            _layer1.style.borderRightColor = _border;
            _layer1.style.borderBottomColor = _border;
            Insert(1, _layer1);

            var _titleContainer = this.Q("title");
            if (_titleContainer != null)
            {
                var _badge = new Label("⧉");
                _badge.AddToClassList("flow-badge");
                _badge.pickingMode = PickingMode.Ignore;
                _badge.tooltip = "Double-click to open sub-graph";
                _badge.style.unityFontStyleAndWeight = FontStyle.Bold;
                _badge.style.fontSize = 13;
                _badge.style.color = new Color(0.92f, 0.93f, 0.96f, 0.9f);
                _badge.style.marginLeft = 4;
                _badge.style.marginRight = 2;
                _badge.style.unityTextAlign = TextAnchor.MiddleCenter;
                _badge.style.alignSelf = Align.Center;
                _titleContainer.Add(_badge);
            }
        }

        public void UpdateTitle()
        {
            title = nodeData.eventData != null ? nodeData.eventData.DisplayName : nodeData.nodeName;
            nodeData.nodeName = title;
        }

        private void DrawEventInspector()
        {
            if (ownerData == null || nodeData?.eventData == null)
                return;

#if ODIN_INSPECTOR
            DrawOdinInspector();
#else
            DrawUnityInspector();
#endif
        }

#if ODIN_INSPECTOR
        private void DrawOdinInspector()
        {
            var _evt = nodeData.eventData;
            if (odinTree == null || odinTreeTarget != _evt)
            {
                odinTree?.Dispose();
                odinTree = PropertyTree.Create(_evt);
                odinTreeTarget = _evt;
            }

            odinTree.UpdateTree();

            int _choiceCountBefore = GetOutputPortCount();
            string _choiceKeysBefore = GetOutputPortSignature();

            GUI.changed = false;
            EditorGUI.BeginChangeCheck();

            odinTree.Draw(false);

            bool _changed = EditorGUI.EndChangeCheck() || GUI.changed;

            if (_changed)
            {
                Undo.RegisterCompleteObjectUndo(ownerData, "Edit Event Field");
                odinTree.ApplyChanges();
                EditorUtility.SetDirty(ownerData);
                UpdateTitle();
                ApplyNodeChrome();
            }

            if (_evt.OutputPorts != null)
            {
                odinTree.ApplyChanges();
                ScheduleOutputPortRefresh(_choiceCountBefore, _choiceKeysBefore);
            }
        }
#endif

        private void DrawUnityInspector()
        {
            if (serializedGraph == null || eventDataProperty == null ||
                eventDataProperty.serializedObject != serializedGraph)
            {
                eventDataProperty = FindEventDataProperty();
                if (eventDataProperty == null) return;
            }

            serializedGraph.UpdateIfRequiredOrScript();

            int _choiceCountBefore = GetOutputPortCount();
            string _choiceKeysBefore = GetOutputPortSignature();

            EditorGUI.BeginChangeCheck();

            var _prop = eventDataProperty.Copy();
            var _endProp = eventDataProperty.GetEndProperty();
            bool _enterChildren = true;
            while (_prop.NextVisible(_enterChildren) && !SerializedProperty.EqualContents(_prop, _endProp))
            {
                _enterChildren = false;
                if (ShouldHideInspectorField(_prop.name))
                    continue;
                EditorGUILayout.PropertyField(_prop, true);
            }

            if (EditorGUI.EndChangeCheck())
            {
                Undo.RegisterCompleteObjectUndo(ownerData, "Edit Event Field");
                serializedGraph.ApplyModifiedProperties();
                EditorUtility.SetDirty(ownerData);
                UpdateTitle();
                ApplyNodeChrome();
            }

            if (nodeData.eventData.OutputPorts != null)
                ScheduleOutputPortRefresh(_choiceCountBefore, _choiceKeysBefore);
        }

        private void ScheduleOutputPortRefresh(int countBefore, string keysBefore)
        {
            int _countNow = GetOutputPortCount();
            string _keysNow = GetOutputPortSignature();
            if (_countNow == countBefore && _keysNow == keysBefore)
                return;
            if (_countNow == lastChoiceCount && _keysNow == lastChoiceKeys)
                return;

            lastChoiceCount = _countNow;
            lastChoiceKeys = _keysNow;

            schedule.Execute(() =>
            {
                if (nodeData?.eventData == null)
                    return;
                var _ports = nodeData.eventData.OutputPorts;
                if (_ports == null)
                {
                    if (extraOutputPorts.Count == 0)
                        return;
                }

                RebuildOutputPorts(true);
                UpdateTitle();
                ApplyNodeChrome();
                MarkDirtyRepaint();
                var _gv = GetFirstAncestorOfType<CutsceneGraphView>();
                _gv?.MarkDirtyRepaint();
            });
        }

        private int GetOutputPortCount()
        {
            var _ports = nodeData?.eventData?.OutputPorts;
            return _ports?.Count ?? 0;
        }

        private string GetOutputPortSignature()
        {
            var _ports = nodeData?.eventData?.OutputPorts;
            if (_ports == null || _ports.Count == 0) return "";
            return string.Join("|", _ports.Select(p => p?.PortID ?? ""));
        }

        private static bool ShouldHideInspectorField(string name)
        {
            if (string.IsNullOrEmpty(name)) return true;
            switch (name)
            {
                case "data":
                case "_runtimeGraph":
                    return true;
                default:
                    return false;
            }
        }

        private int FindNodeIndex()
        {
            if (ownerData?.data.nodes == null || nodeData == null) return -1;
            for (int _i = 0; _i < ownerData?.data.nodes.Count; _i++)
            {
                if (ownerData?.data.nodes[_i] != null && ownerData?.data.nodes[_i].guid == nodeData.guid)
                    return _i;
            }
            return -1;
        }

        private SerializedProperty FindEventDataProperty()
        {
            if (ownerData == null) return null;

            serializedGraph = new SerializedObject(ownerData);
            var _dataProp = serializedGraph.FindProperty("data");
            if (_dataProp == null) return null;
            var _nodesProp = _dataProp.FindPropertyRelative("nodes");
            if (_nodesProp == null || !_nodesProp.isArray) return null;

            for (int _i = 0; _i < _nodesProp.arraySize; _i++)
            {
                var _nodeProp = _nodesProp.GetArrayElementAtIndex(_i);
                var _guidProp = _nodeProp.FindPropertyRelative("guid");
                if (_guidProp == null || _guidProp.stringValue != guid) continue;
                cachedNodeIndex = _i;
                return _nodeProp.FindPropertyRelative("eventData");
            }
            return null;
        }

        private void BuildNodeContextMenu(ContextualMenuPopulateEvent evt)
        {
            if (IsStartNode) return;

            var _graphView = GetFirstAncestorOfType<GraphView>();
            if (_graphView == null) return;

            var _selectedNodes = _graphView.selection.OfType<CutsceneNodeView>()
                .Where(n => !n.IsStartNode)
                .ToList();

            if (!_selectedNodes.Contains(this))
                _selectedNodes.Insert(0, this);

            var _toRemove = _selectedNodes
                .Select(n => new
                {
                    Node = n,
                    Group = _graphView.graphElements.OfType<CutsceneGroup>()
                        .FirstOrDefault(g => g.ContainsNode(n))
                })
                .Where(x => x.Group != null)
                .ToList();

            if (_toRemove.Count > 0)
            {
                string _label = _toRemove.Count == 1
                    ? "Remove from Group"
                    : $"Remove {_toRemove.Count} Nodes from Group";

                evt.menu.AppendAction(_label, _ =>
                {
                    foreach (var _item in _toRemove)
                        _item.Group.RemoveNode(_item.Node);
                }, DropdownMenuAction.AlwaysEnabled);
            }
        }

        public override void SetPosition(Rect newPos)
        {
            base.SetPosition(newPos);
            nodeData.position = newPos.position;
        }

        public override void OnSelected()
        {
            base.OnSelected();
            style.scale = new Scale(new Vector3(1.035f, 1.035f, 1f));
            ApplyNodeChrome();
        }

        public override void OnUnselected()
        {
            base.OnUnselected();
            style.scale = new Scale(Vector3.one);
            ApplyNodeChrome();
        }

        public static CutsceneEvent CloneEvent(CutsceneEvent source)
        {
            if (source == null) return null;

            var _clone = Activator.CreateInstance(source.GetType()) as CutsceneEvent;
            if (_clone == null) return null;

            var _json = JsonUtility.ToJson(source);
            JsonUtility.FromJsonOverwrite(_json, _clone);

            var _fields = source.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            foreach (var _field in _fields)
            {
                if (!typeof(UnityEngine.Object).IsAssignableFrom(_field.FieldType)) continue;
                _field.SetValue(_clone, _field.GetValue(source));
            }


            return _clone;
        }
    }
}